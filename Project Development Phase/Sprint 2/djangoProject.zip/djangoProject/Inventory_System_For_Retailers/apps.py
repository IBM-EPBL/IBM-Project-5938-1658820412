from django.apps import AppConfig


class InventorySystemForRetailersConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'Inventory_System_For_Retailers'
